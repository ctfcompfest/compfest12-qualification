.. _examples:

Examples
========

**Block Analysis**
    *Current Status:*

**Chest Analysis**
    *Current Status:* McRegion and Anvil maps
    This example shows loading a Minecraft world, and moving through it, using a dictionary-like interface.
    Tags

**Generate Leve.dat**
    *Current Status:*

**Map**
    *Current Status:*

**Mob Analysis**
    *Current Status:*

**Utilities**
    *Current Status:*

**Biome Analysis**
    *Current Status:* Anvil maps only

